# Guide complet et détaillé — Stripe + Netlify  
## Institut Barbarella · Paiement des acomptes en ligne

Ce document est le mode d’emploi **pas à pas**, du compte Stripe jusqu’au premier paiement test, puis au passage en production.

Temps estimé première config : **20 à 40 minutes**.

---

## Table des matières

1. [Comment ça marche (schéma)](#1-comment-ça-marche-schéma)
2. [Ce dont tu as besoin](#2-ce-dont-tu-as-besoin)
3. [Étape A — Compte Stripe](#3-étape-a--compte-stripe)
4. [Étape B — Fichiers à déployer](#4-étape-b--fichiers-à-déployer)
5. [Étape C — Créer le site sur Netlify](#5-étape-c--créer-le-site-sur-netlify)
6. [Étape D — Variables d’environnement](#6-étape-d--variables-denvironnement)
7. [Étape E — Brancher Stripe dans le site](#7-étape-e--brancher-stripe-dans-le-site)
8. [Étape F — Webhooks Stripe](#8-étape-f--webhooks-stripe)
9. [Étape G — Tester de A à Z](#9-étape-g--tester-de-a-à-z)
10. [Passage en production (Live)](#10-passage-en-production-live)
11. [Nom de domaine personnalisé](#11-nom-de-domaine-personnalisé)
12. [Sécurité & bonnes pratiques](#12-sécurité--bonnes-pratiques)
13. [Dépannage (tableau + cas par cas)](#13-dépannage-tableau--cas-par-cas)
14. [FAQ](#14-faq)
15. [Checklist finale](#15-checklist-finale)
16. [Résumé ultra-court](#16-résumé-ultra-court)

---

## 1. Comment ça marche (schéma)

```
CLIENT sur ton site
   │
   │  Clique « Confirmer · 29,99 € » (mode Carte)
   ▼
SITE (index.html)
   │  Envoie au proxy : montant, email, nom, soin, URLs retour
   ▼
NETLIFY FUNCTION  create-checkout
   │  Utilise STRIPE_SECRET_KEY (cachée côté serveur)
   │  Crée une Session Checkout Stripe
   │  Renvoie { url: "https://checkout.stripe.com/..." }
   ▼
CLIENT redirigé → page de paiement Stripe (sécurisée)
   │  Paie avec carte (test ou réelle)
   ▼
STRIPE
   │  1) Redirige le client vers ton site (?paid=1)
   │  2) Envoie un WEBHOOK vers ton serveur
   ▼
NETLIFY FUNCTION  stripe-webhook
   │  Vérifie la signature (whsec_…)
   │  Log : nom, email, téléphone, soin, montant
   ▼
TOI  → tu vois le paiement dans Stripe Dashboard + logs Netlify
```

### Pourquoi un « proxy » ?

- La **clé secrète** Stripe (`sk_…`) ne doit **jamais** être dans le navigateur (sinon n’importe qui pourrait encaisser ou rembourser à ta place).
- Netlify Functions = petit serveur gratuit qui garde le secret et parle à Stripe pour toi.

### Acomptes déjà calculés par le site

| Catégorie | Acompte |
|-----------|---------|
| Massages | **29,99 €** |
| Épilation (sauf intégrale) | **4,99 €** |
| Épilation intégrale (ex. maillot intégral) | **29,99 €** |
| Manucure / Pédicure | **9,99 €** |
| Produits dérivés | **0 €** (paiement sur place) |

---

## 2. Ce dont tu as besoin

| Élément | Détail |
|---------|--------|
| Email | Pour Stripe et Netlify |
| Navigateur | Chrome, Firefox ou Safari |
| Dossier projet | Voir section 4 |
| Compte Stripe | Gratuit à créer |
| Compte Netlify | Gratuit (plan Starter suffisant) |
| Temps | 20–40 min la première fois |

**Identifiants Espace Pro du site (à changer ensuite) :**  
`admin` / `admin2026`

---

## 3. Étape A — Compte Stripe

### A1. Création

1. Ouvre **https://dashboard.stripe.com/register**
2. Inscris-toi (email pro de préférence)
3. Confirme l’email si demandé
4. Choisis le pays **France** (important pour les paiements et la TVA)

### A2. Rester en mode Test

En haut à droite du Dashboard, un interrupteur **Test mode** (souvent orange) doit être **activé**.

- Mode Test = fausse monnaie, cartes de test, **aucun débit réel**
- Tu ne passes en Live que quand tout fonctionne (section 10)

### A3. Récupérer les clés API

1. Menu de gauche → **Developers** (Développeurs)  
2. **API keys** (Clés API)
3. Tu vois :

| Nom affiché | Exemple | Où la mettre |
|-------------|---------|--------------|
| **Publishable key** | `pk_test_51N…` | Dans le **site** (Admin → Stripe) |
| **Secret key** | `sk_test_51N…` | **Uniquement** dans Netlify (variables d’environnement) |

4. Clique **Reveal test key** pour afficher la secret key  
5. Copie les deux clés dans un gestionnaire de mots de passe (1Password, Bitwarden, notes chiffrées…)

⚠️ Ne colle **jamais** `sk_test_` ou `sk_live_` dans le fichier HTML, ni dans un message, ni dans un repo Git public.

### A4. Textes utiles pour Stripe (profil entreprise)

Si Stripe demande une **description d’activité** :

```
Institut de beauté et bien-être proposant des massages, de l’épilation
à la cire orientale, des soins manucure et pédicure, ainsi que la vente
de produits de soin (huiles, bougies, savons).
Encaissement d’acomptes de réservation en ligne.
```

**Statement descriptor** (ce qui apparaît sur le relevé bancaire du client) :  
`BARBARELLA` ou `INSTITUT BARBARELLA`  
(max. 22 caractères, **sans accents**, de préférence en majuscules)

---

## 4. Étape B — Fichiers à déployer

Sur ton ordinateur, prépare un dossier (ex. `barbarella-netlify`) avec **exactement** :

```
barbarella-netlify/
├── index.html              ← le site (copie de institut-barbarella.html)
├── netlify.toml            ← dit à Netlify où sont les fonctions
├── package.json            ← installe la librairie stripe
└── functions/
    ├── create-checkout.js  ← crée la page de paiement
    └── stripe-webhook.js   ← reçoit « paiement OK » de Stripe
```

Ces fichiers sont déjà dans le projet fourni :

- `/home/workdir/artifacts/netlify/` (dossier prêt à uploader)
- ou copie `institut-barbarella.html` → renomme en `index.html`

### Rôle de chaque fichier (en une phrase)

| Fichier | Rôle |
|---------|------|
| `index.html` | Site public + Espace Pro |
| `netlify.toml` | « Publie ce dossier et charge les fonctions dans `/functions` » |
| `package.json` | « Installe le package npm `stripe` » |
| `create-checkout.js` | Reçoit la demande d’acompte → crée une session Stripe → renvoie l’URL de paiement |
| `stripe-webhook.js` | Stripe appelle cette URL quand le paiement est confirmé |

Tu n’as **pas** besoin de connaître Node.js pour déployer : Netlify s’occupe de l’installation.

---

## 5. Étape C — Créer le site sur Netlify

### Option 1 — Drag & drop (recommandé pour commencer)

1. Va sur **https://app.netlify.com** → inscris-toi / connecte-toi  
2. Depuis le tableau de bord : **Add new site** → **Deploy manually**  
   (parfois : « Sites » → « Add new site » → « Deploy manually »)  
3. **Glisse le dossier entier** `barbarella-netlify` (pas seulement `index.html`)  
4. Attends 1 à 3 minutes  
5. Netlify affiche une URL du type :  
   `https://joyful-pudding-a1b2c3.netlify.app`

Note cette URL : on l’appellera **`https://TON-SITE.netlify.app`** dans la suite.

### Option 2 — Via GitHub (mieux pour les mises à jour)

1. Crée un dépôt GitHub et envoie le contenu du dossier  
2. Netlify → **Add new site** → **Import an existing project**  
3. Autorise GitHub → sélectionne le dépôt  
4. Réglages :
   - **Build command** : laisse vide  
   - **Publish directory** : `.`  
   - Les fonctions sont déjà indiquées par `netlify.toml`  
5. **Deploy site**

À chaque `git push`, Netlify redéploie automatiquement.

### Vérifier que les fonctions sont bien là

1. Netlify → ton site  
2. Menu **Functions** (ou **Project configuration** → Functions)  
3. Tu dois voir :
   - `create-checkout`
   - `stripe-webhook`

**Si la liste est vide :** le dossier `functions/` n’a pas été uploadé → recommence le deploy avec le dossier complet.

### URLs de tes fonctions (à garder)

```
https://TON-SITE.netlify.app/.netlify/functions/create-checkout
https://TON-SITE.netlify.app/.netlify/functions/stripe-webhook
```

---

## 6. Étape D — Variables d’environnement

Les secrets ne vont **pas** dans le code : ils vont dans Netlify.

1. Netlify → ton site  
2. **Site configuration** (ou **Project configuration**)  
3. **Environment variables** → **Add a variable** / **Add environment variables**

### Variables à créer

| Key (nom exact) | Value | Quand |
|-----------------|--------|------|
| `STRIPE_SECRET_KEY` | `sk_test_…` | Maintenant |
| `STRIPE_WEBHOOK_SECRET` | `whsec_…` | Après l’étape F (tu peux laisser vide pour l’instant) |

4. Scope : **All** (ou Production + Deploy previews)  
5. **Save**  
6. **Indispensable :** menu **Deploys** → **Trigger deploy** → **Deploy site**  

Sans ce redeploy, les fonctions tournent encore **sans** la nouvelle variable.

### Comment vérifier

- Ouvre les **Logs** de la fonction `create-checkout` pendant un test  
- Si tu vois `STRIPE_SECRET_KEY manquante` → variable absente ou redeploy oublié  

---

## 7. Étape E — Brancher Stripe dans le site

1. Ouvre `https://TON-SITE.netlify.app`  
2. Clique **Espace Pro**  
3. Login : `admin` / `admin2026`  
4. Menu → **Admin**  
5. Section **Stripe · Paiement acomptes**

### Remplir ainsi

| Champ | Valeur exacte |
|-------|----------------|
| ☑ Activer Stripe | **Coché** |
| Clé publiable | `pk_test_…` (celle de Stripe) |
| Mode | **Test** |
| Proxy paiement | `https://TON-SITE.netlify.app/.netlify/functions/create-checkout` |
| Description activité | Déjà préremplie (tu peux laisser) |

6. Clique **Enregistrer Stripe**  
7. Tu dois voir un message de confirmation (✓)

### Exemple concret

Si ton site est `https://institut-barbarella-demo.netlify.app` :

```
Proxy = https://institut-barbarella-demo.netlify.app/.netlify/functions/create-checkout
```

Sans `https://` ou avec une faute de frappe → le paiement ne démarrera pas.

---

## 8. Étape F — Webhooks Stripe

### À quoi ça sert ?

Quand le client **a bien payé**, Stripe appelle ton URL webhook.  
Même s’il ferme la page, **toi** tu es informé (logs Netlify + Dashboard Stripe).

### F1. Créer l’endpoint

1. Stripe Dashboard → reste en **Test mode**  
2. **Developers** → **Webhooks**  
3. **Add endpoint**  
4. **Endpoint URL** :

```
https://TON-SITE.netlify.app/.netlify/functions/stripe-webhook
```

5. **Select events** → coche au minimum :
   - `checkout.session.completed` ← **obligatoire** (acompte payé)
   - `checkout.session.expired` (session abandonnée)
   - `payment_intent.payment_failed` (carte refusée)

6. **Add endpoint**

### F2. Signing secret

1. Clique sur l’endpoint créé  
2. **Signing secret** → **Reveal**  
3. Copie la valeur qui commence par `whsec_`

### F3. Dans Netlify

1. Environment variables → ajoute / mets à jour :
   - Key : `STRIPE_WEBHOOK_SECRET`  
   - Value : `whsec_…`  
2. **Trigger deploy** encore une fois  

### F4. Test sans carte

1. Stripe → Webhooks → ton endpoint → **Send test events**  
2. Choisis `checkout.session.completed` → Send  
3. Netlify → **Functions** → `stripe-webhook` → **Logs**  
4. Tu dois voir quelque chose comme : `✓ Acompte payé`

- Réponse **200** dans Stripe = OK  
- Réponse **400** = mauvais `whsec_` ou redeploy pas fait  

---

## 9. Étape G — Tester de A à Z

### G1. Parcours client complet

1. Site public → **Réserver**  
2. Catégorie **Massages** → un soin (ex. Massage Iris)  
3. Mode de paiement : **Carte**  
4. Remplis : prénom, nom, email, téléphone, date de naissance  
5. Clique **Confirmer · 29,99 €**  
6. **Résultat attendu :** redirection vers `checkout.stripe.com`  

### G2. Cartes de test Stripe

Sur la page Checkout Stripe :

| Scénario | Numéro | Résultat |
|----------|--------|----------|
| Succès | `4242 4242 4242 4242` | Paiement accepté |
| Refus | `4000 0000 0000 0002` | Échec |
| 3D Secure | `4000 0025 0000 3155` | Authentification demandée |

- **Date** : n’importe quelle date future (ex. `12/34`)  
- **CVC** : n’importe quels 3 chiffres (ex. `123`)  
- **Nom / adresse** : libres  

### G3. Après un paiement réussi

1. Retour sur ton site (URL avec `?paid=1`)  
2. Stripe → **Payments** : le paiement apparaît (29,99 €, etc.)  
3. Netlify → Logs `stripe-webhook` : `✓ Acompte payé` + email + soin  
4. Espace Pro → réservations / fil d’activité : la demande est visible (côté site)

### G4. Test « Sur place »

Choisis **Sur place** → pas de Stripe → confirmation locale uniquement. C’est normal.

### G5. Test rapide du proxy (optionnel, avancé)

Dans un terminal (ou Postman) :

```bash
curl -X POST "https://TON-SITE.netlify.app/.netlify/functions/create-checkout" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 2999,
    "currency": "eur",
    "name": "Test Client",
    "email": "test@example.com",
    "soin": "Massage Iris",
    "success_url": "https://TON-SITE.netlify.app/?paid=1",
    "cancel_url": "https://TON-SITE.netlify.app/?cancel=1"
  }'
```

Réponse attendue : JSON avec `"url": "https://checkout.stripe.com/..."`  
(`amount` est en **centimes** : 2999 = 29,99 €)

---

## 10. Passage en production (Live)

Uniquement quand les tests sont OK.

### 10.1 Activer le compte Stripe

1. Désactive **Test mode**  
2. Complète le dossier (KYC) : identité, IBAN, adresse de l’institut  
3. Validation Stripe : souvent 1 à 2 jours ouvrés  

### 10.2 Clés Live

Developers → API keys (**Live**) :

- `pk_live_…`  
- `sk_live_…`  

### 10.3 Netlify

| Variable | Nouvelle valeur |
|----------|-----------------|
| `STRIPE_SECRET_KEY` | `sk_live_…` |

Puis **Trigger deploy**.

### 10.4 Site (Admin)

- Clé publiable : `pk_live_…`  
- Mode : **Live**  
- Proxy : **inchangé** (même URL de fonction)  
- Enregistrer  

### 10.5 Webhook Live

Les webhooks Test et Live sont **séparés**.

1. Dashboard en mode **Live**  
2. Nouvel endpoint, **même URL** `…/stripe-webhook`  
3. Mêmes événements  
4. Nouveau `whsec_…` → mets à jour `STRIPE_WEBHOOK_SECRET`  
5. Redeploy Netlify  

### 10.6 Premier vrai paiement

Fais un petit acompte (ex. 4,99 €) avec ta carte, vérifie réception, puis **Refund** depuis Stripe → Payments si tu veux te rembourser.

---

## 11. Nom de domaine personnalisé

1. Netlify → **Domain management** → **Add custom domain**  
2. Ex. `www.institut-barbarella.fr`  
3. Configure les DNS chez ton registrar (OVH, Gandi, Cloudflare…) comme indiqué par Netlify  
4. HTTPS : activé automatiquement (Let’s Encrypt)  
5. **Mets à jour** :
   - Admin → Proxy : `https://www.ton-domaine.fr/.netlify/functions/create-checkout`  
   - Stripe Webhooks → nouvelle URL `…/stripe-webhook`  

---

## 12. Sécurité & bonnes pratiques

| Règle | Pourquoi |
|-------|----------|
| `sk_` et `whsec_` uniquement dans Netlify Env | Évite le vol de clés |
| Jamais de secret dans Git public | Scan bots |
| HTTPS obligatoire | Stripe et navigateurs l’exigent |
| Changer `admin` / `admin2026` | Accès Dashboard |
| Statement descriptor clair | Moins de litiges bancaires |
| Logs webhook | Preuve de paiement côté serveur |
| Mode Test d’abord | Zéro risque avant l’ouverture |

En version plus avancée plus tard : recalculer le montant de l’acompte **côté serveur** (pour qu’un client ne puisse pas modifier le prix dans le navigateur). Pour un institut avec acomptes fixes, le flux actuel est déjà solide.

---

## 13. Dépannage (tableau + cas par cas)

| Symptôme | Cause probable | Que faire |
|----------|----------------|-----------|
| Clic Confirmer → rien | Stripe pas activé dans Admin | Cocher « Activer Stripe » + Enregistrer |
| Message « aucun proxy » | Champ Proxy vide | Coller l’URL `…/create-checkout` |
| Erreur 500 proxy | Secret key absente | Env var + **redeploy** |
| Log « STRIPE_SECRET_KEY manquante » | Variable pas chargée | Vérifier le nom exact + redeploy |
| Webhook 400 | Mauvais `whsec_` | Recopier Signing secret + redeploy |
| Fonctions absentes | Mauvais upload | Redeploy le dossier avec `functions/` |
| Page blanche | Pas de `index.html` à la racine | Renommer le HTML en `index.html` |
| CORS dans la console | URL proxy incorrecte | Vérifier https + chemin exact |
| Paiement OK mais pas de log webhook | Webhook mal configuré | Test event Stripe + vérifier URL |
| Montant refusé | < 0,50 € | Ne concerne pas tes acomptes (≥ 4,99 €) |

### Où regarder les logs

- **Netlify** : Site → Functions → `create-checkout` ou `stripe-webhook` → Logs  
- **Stripe** : Developers → Logs / Webhooks → détail de chaque événement (code HTTP 200 = OK)

---

## 14. FAQ

**Q : Est-ce que Netlify est gratuit ?**  
Oui pour ce usage (trafic institut + fonctions légères). Surveille les quotas si un jour le volume explose.

**Q : Je peux utiliser un autre hébergeur ?**  
Oui (Cloudflare Workers, Vercel, un VPS PHP…). Il faut équivalent : une URL HTTPS qui crée la session Stripe avec la secret key.

**Q : Le client paie l’acompte : comment je vois le RDV ?**  
Dans l’Espace Pro (réservations / fil) + Stripe Payments + logs webhook. Tu peux ensuite appeler le client pour confirmer le créneau exact.

**Q : Faut-il un terminal de paiement physique ?**  
Non pour les acomptes en ligne. Le solde peut se régler sur place (espèces / TPE).

**Q : TVA ?**  
Selon ton régime (micro, franchise en base, etc.). Stripe peut ajouter la TVA plus tard ; un comptable te dira le bon paramétrage.

**Q : Plusieurs établissements ?**  
Un compte Stripe (ou plusieurs) + éventuellement un proxy par site. Pour l’instant le setup est mono-institut.

---

## 15. Checklist finale

### Avant d’ouvrir les acomptes en Test

- [ ] Compte Stripe créé, **Test mode** ON  
- [ ] `pk_test_` et `sk_test_` notées au safe  
- [ ] Dossier déployé sur Netlify, URL OK  
- [ ] Fonctions `create-checkout` et `stripe-webhook` visibles  
- [ ] `STRIPE_SECRET_KEY` dans Netlify + redeploy  
- [ ] Admin : Stripe activé + `pk_test_` + URL proxy  
- [ ] Webhook créé + `STRIPE_WEBHOOK_SECRET` + redeploy  
- [ ] Test carte `4242…` réussi + log `✓ Acompte payé`  
- [ ] Mot de passe admin changé  

### Avant de vrais encaissements

- [ ] KYC Stripe validé (Live)  
- [ ] Clés `pk_live_` / `sk_live_` en place  
- [ ] Webhook **Live** + nouveau `whsec_`  
- [ ] Micro-paiement réel testé (et remboursé si besoin)  
- [ ] Domaine custom (optionnel) + proxy / webhook mis à jour  

---

## 16. Résumé ultra-court

1. **Stripe** → créer compte, récupérer `pk_test_` + `sk_test_`  
2. **Netlify** → déployer le dossier `netlify/`  
3. **Netlify Env** → `STRIPE_SECRET_KEY` = `sk_test_…` → redeploy  
4. **Site Admin** → activer Stripe, coller `pk_test_…` + URL `…/create-checkout`  
5. **Webhook** → URL `…/stripe-webhook` + `STRIPE_WEBHOOK_SECRET` → redeploy  
6. **Test** → réserver un massage, carte `4242 4242 4242 4242`  
7. **Live** → quand tu es prêt à encaisser pour de vrai  

---

## Fichiers du projet

| Fichier | Rôle |
|---------|------|
| `institut-barbarella.html` | Site + Dashboard (version de travail) |
| `netlify/index.html` | Même site prêt pour Netlify |
| `netlify/functions/create-checkout.js` | Création session de paiement |
| `netlify/functions/stripe-webhook.js` | Confirmation de paiement |
| `netlify/netlify.toml` | Config Netlify |
| `netlify/package.json` | Dépendance `stripe` |
| `GUIDE-Stripe-Netlify.md` | **Ce guide** |

---

En cas de blocage, envoie **le message d’erreur exact** (navigateur, log Netlify ou écran Stripe) et l’étape où tu en es (A–G) : on corrige point par point.
