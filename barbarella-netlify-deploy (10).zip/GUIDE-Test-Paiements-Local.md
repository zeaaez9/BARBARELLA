# Tester les paiements Stripe en local  
## Institut Barbarella

Ce guide permet de **simuler un vrai parcours de paiement** sur ta machine, sans déployer à chaque fois.

Tu auras besoin de :
- Node.js (https://nodejs.org)
- Compte Stripe (mode **Test**)
- Les clés `pk_test_…` et `sk_test_…`

---

## 1. Vue d’ensemble

```
Navigateur (site local)
        ↓  POST acompte
Netlify Dev  →  create-checkout (localhost)
        ↓
Stripe Checkout (page officielle)
        ↓  paiement carte test
Stripe CLI  →  redirige le webhook vers stripe-webhook (localhost)
```

**Important :** le site seul (ouvrir le HTML en double-clic) **ne suffit pas** pour Stripe : il faut un petit serveur local pour la clé secrète.

---

## 2. Installation des outils (une seule fois)

### 2.1 Node.js
Vérifie dans un terminal :
```bash
node -v
npm -v
```
Si absent → installe LTS sur https://nodejs.org

### 2.2 Netlify CLI
```bash
npm install -g netlify-cli
netlify -v
```

### 2.3 Stripe CLI
- Mac : `brew install stripe/stripe-cli/stripe`
- Windows / Linux : https://stripe.com/docs/stripe-cli

Puis :
```bash
stripe login
```
(une page Stripe s’ouvre pour autoriser le CLI)

---

## 3. Préparer le dossier local

1. Dézippe `barbarella-netlify-deploy.zip` (ou utilise le dossier `netlify/`)
2. Ouvre un terminal **dans ce dossier** (là où sont `index.html`, `netlify.toml`, `functions/`)

```bash
cd chemin/vers/netlify
npm install
```
Cela installe le package `stripe` pour les fonctions.

### Fichier `.env` (secrets locaux)

Crée un fichier **`.env`** à la racine du dossier `netlify` :

```env
STRIPE_SECRET_KEY=sk_test_XXXXXXXX
STRIPE_WEBHOOK_SECRET=whsec_XXXXXXXX
```

- `STRIPE_SECRET_KEY` : Dashboard Stripe → Developers → API keys → Secret key (Test)
- `STRIPE_WEBHOOK_SECRET` : on le récupère à l’étape 5 avec `stripe listen`

⚠️ Ne commit **jamais** ce fichier `.env` sur GitHub.

---

## 4. Lancer le site + les fonctions en local

Dans le dossier `netlify` :

```bash
netlify dev
```

Tu devrais voir quelque chose comme :
```
◈ Server now ready on http://localhost:8888
```

Ouvre : **http://localhost:8888**

### Brancher Stripe dans l’Espace Pro (local)

1. http://localhost:8888 → **Espace Pro** → `admin` / `admin2026`
2. **Admin** → Stripe :
   - ☑ Activer Stripe
   - Clé publiable : `pk_test_…`
   - Mode : **Test**
   - Proxy : `http://localhost:8888/.netlify/functions/create-checkout`
3. **Enregistrer Stripe**

> Note : en local le proxy est en `http://` (pas https). C’est normal pour `netlify dev`.

---

## 5. Webhooks en local (Stripe CLI)

Ouvre un **2ᵉ terminal** :

```bash
stripe listen --forward-to localhost:8888/.netlify/functions/stripe-webhook
```

Stripe affiche :
```
Ready! Your webhook signing secret is whsec_xxxxxxxxxxxxx
```

1. Copie ce `whsec_…`
2. Mets-le dans ton fichier `.env` :
   ```env
   STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxx
   ```
3. **Redémarre** `netlify dev` (Ctrl+C puis `netlify dev` à nouveau)  
   pour qu’il relise le `.env`

Laisse `stripe listen` **ouvert** pendant tous les tests.

---

## 6. Faire un paiement test

1. Sur http://localhost:8888 → section **Réserver**
2. Choisis un **massage** (acompte 29,99 €)
3. Mode **Carte**
4. Remplis le formulaire (email, date de naissance, etc.)
5. **Confirmer · 29,99 €**
6. Tu es redirigé vers **checkout.stripe.com**

### Carte de test

| Champ | Valeur |
|-------|--------|
| Numéro | `4242 4242 4242 4242` |
| Date | n’importe quelle date future (ex. 12/34) |
| CVC | 123 |
| Nom / adresse | libres |

Autres cartes utiles :
- Refus : `4000 0000 0000 0002`
- 3D Secure : `4000 0025 0000 3155`

### Résultats attendus

1. Retour sur le site avec `?paid=1` → message **Acompte reçu**
2. Terminal `stripe listen` → événement `checkout.session.completed`
3. Logs Netlify Dev → `✓ Acompte payé`
4. Stripe Dashboard (Test) → **Payments** : le paiement apparaît

---

## 7. Tester sans interface (curl)

Avec `netlify dev` lancé :

```bash
curl -X POST "http://localhost:8888/.netlify/functions/create-checkout" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 2999,
    "currency": "eur",
    "name": "Test Local",
    "email": "test@example.com",
    "soin": "Massage Iris",
    "tel": "+33600000000",
    "success_url": "http://localhost:8888/?paid=1#reserver",
    "cancel_url": "http://localhost:8888/?cancel=1#reserver",
    "description": "Test local Barbarella"
  }'
```

Réponse OK :
```json
{ "url": "https://checkout.stripe.com/c/pay/cs_test_...", "id": "cs_test_..." }
```

Ouvre l’`url` dans le navigateur pour payer avec `4242…`.

---

## 8. Tester les erreurs

| Test | Comment | Résultat attendu |
|------|---------|------------------|
| Proxy faux | Admin → Proxy = `http://localhost:8888/mauvais` | Message 404 clair |
| Secret manquant | Enlever `STRIPE_SECRET_KEY` du `.env`, relancer | Message « clé manquante » |
| Carte refusée | `4000 0000 0000 0002` | Échec sur la page Stripe |
| Annulation | Fermer Checkout ou bouton retour | `?cancel=1` + alerte |
| Webhook secret faux | Mauvais `whsec_` dans `.env` | `stripe listen` montre 400 |

---

## 9. Variante : tester le site local contre Netlify déjà déployé

Si les fonctions sont **déjà en ligne** sur Netlify :

1. Ouvre le HTML en local **ou** via un petit serveur :
   ```bash
   npx serve .
   ```
2. Espace Pro → Proxy =
   ```
   https://TON-SITE.netlify.app/.netlify/functions/create-checkout
   ```
3. Pas besoin de `netlify dev` ni Stripe CLI pour le **paiement**
4. Les webhooks iront vers l’URL Netlify (déjà configurée en prod/test)

Utile pour tester seulement le front, sans installer le CLI.

---

## 10. Commandes récap (2 terminaux)

**Terminal 1 — site + fonctions**
```bash
cd netlify
npm install          # une fois
# éditer .env avec sk_test_ et whsec_
netlify dev
```

**Terminal 2 — webhooks**
```bash
stripe listen --forward-to localhost:8888/.netlify/functions/stripe-webhook
# copier whsec_ → .env → relancer terminal 1
```

**Navigateur**
```
http://localhost:8888
```

**Carte test**
```
4242 4242 4242 4242
```

---

## 11. Problèmes fréquents en local

| Problème | Solution |
|----------|----------|
| `netlify: command not found` | `npm install -g netlify-cli` |
| `stripe: command not found` | Installer Stripe CLI + `stripe login` |
| Fonction 500 « secret manquante » | Fichier `.env` à la racine + redémarrer `netlify dev` |
| CORS / fetch failed | Vérifier proxy = `http://localhost:8888/.netlify/functions/create-checkout` |
| Webhook 400 | `whsec_` de `stripe listen` (pas celui du Dashboard cloud) + restart |
| Port 8888 occupé | `netlify dev --port 9999` et adapter l’URL proxy |
| `npm install` échoue | Vérifier Node 18+ |

---

## 12. Checklist test local

- [ ] `npm install` dans le dossier netlify  
- [ ] `.env` avec `STRIPE_SECRET_KEY=sk_test_…`  
- [ ] `netlify dev` → http://localhost:8888 OK  
- [ ] Admin → Stripe activé + `pk_test_` + proxy localhost  
- [ ] `stripe listen` + `whsec_` dans `.env` + restart  
- [ ] Réservation massage → carte `4242…` → succès  
- [ ] Log `✓ Acompte payé` visible  
- [ ] Test annulation `?cancel=1`  
- [ ] Test carte refusée  

Quand tout est vert en local, tu peux déployer le même dossier sur Netlify et refaire les mêmes tests en ligne (guide Stripe + Netlify).
